import { useState } from "react";
import Auth from "../../UI/src/components/Auth";
import Dashboard from "../../UI/src/components/Dashboard";
import EvaluationModal from "../../LOGIC/src/components/EvaluationModal";

function App() {
  const [user, setUser] = useState(null);
  const [showEval, setShowEval] = useState(false);

  if (!user) {
    return <Auth onAuth={setUser} />;
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Dashboard user={user} onEvaluate={() => setShowEval(true)} />

      {showEval && (
        <EvaluationModal
          onClose={() => setShowEval(false)}
        />
      )}
    </div>
  );
}

export default App;
