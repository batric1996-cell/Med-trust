/*
  # Medical Trust Evaluation System - Complete Schema with Security

  ## 1. New Tables
  
  ### profiles
  - `id` (uuid, primary key) - Links to auth.users
  - `full_name` (text) - User's full name
  - `trust_band` (text) - Trust level: 'unverified', 'bronze', 'silver', 'gold', 'platinum'
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp
  
  ### peer_reviews
  - `id` (uuid, primary key) - Unique review identifier
  - `evaluator_id` (uuid) - Who is giving the review (FK to profiles)
  - `evaluated_id` (uuid) - Who is being reviewed (FK to profiles)
  - `traits` (text array) - 1-3 traits selected from predefined list
  - `created_at` (timestamptz) - Review creation timestamp
  
  ## 2. Security Features
  
  ### RLS Policies (Zero-Trust)
  
  #### profiles table:
  - SELECT: Authenticated users can read all profiles
  - INSERT: Users can only create their own profile (id = auth.uid())
  - UPDATE: Users can only update their own profile (id = auth.uid())
    - CRITICAL: trust_band column is READ-ONLY from application
    - trust_band can ONLY be modified by database triggers
  
  #### peer_reviews table:
  - SELECT: Authenticated users can read all reviews
  - INSERT: Users can only submit reviews as themselves (evaluator_id = auth.uid())
    - Enforced at RLS level: evaluator_id MUST equal auth.uid()
    - CHECK constraint: Cannot review yourself (evaluator_id != evaluated_id)
    - CHECK constraint: Must select 1-3 traits
  - UPDATE: DISABLED (reviews are immutable)
  - DELETE: DISABLED (reviews cannot be removed)
  
  ### Database Constraints
  - UNIQUE (evaluator_id, evaluated_id) - One review per evaluator-evaluated pair
  - CHECK: No self-evaluation
  - CHECK: Traits array length between 1 and 3
  
  ## 3. Trust Band Calculation
  
  ### Trigger Function
  - Automatically updates trust_band after each peer review
  - Calculation logic:
    - Count distinct evaluators for the user
    - Update trust_band based on evaluation count:
      - 0 evaluations: 'unverified'
      - 1-2: 'bronze'
      - 3-5: 'silver'
      - 6-9: 'gold'
      - 10+: 'platinum'
  
  ## 4. Important Security Notes
  
  - evaluator_id is NEVER trusted from client
  - RLS enforces evaluator_id = auth.uid() at database level
  - trust_band is computed by database only
  - All policies are RESTRICTIVE by default
  - Zero-trust architecture: every access is authenticated and authorized
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  trust_band text DEFAULT 'unverified' CHECK (trust_band IN ('unverified', 'bronze', 'silver', 'gold', 'platinum')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create peer_reviews table
CREATE TABLE IF NOT EXISTS peer_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  evaluator_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  evaluated_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  traits text[] NOT NULL CHECK (array_length(traits, 1) BETWEEN 1 AND 3),
  created_at timestamptz DEFAULT now(),
  
  -- Constraints
  UNIQUE (evaluator_id, evaluated_id),
  CHECK (evaluator_id != evaluated_id)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_peer_reviews_evaluator ON peer_reviews(evaluator_id);
CREATE INDEX IF NOT EXISTS idx_peer_reviews_evaluated ON peer_reviews(evaluated_id);
CREATE INDEX IF NOT EXISTS idx_profiles_trust_band ON profiles(trust_band);

-- Function to update trust_band based on peer review count
CREATE OR REPLACE FUNCTION update_trust_band()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  eval_count INTEGER;
  new_band text;
BEGIN
  -- Count distinct evaluators for the evaluated user
  SELECT COUNT(DISTINCT evaluator_id)
  INTO eval_count
  FROM peer_reviews
  WHERE evaluated_id = NEW.evaluated_id;
  
  -- Determine trust band based on count
  IF eval_count >= 10 THEN
    new_band := 'platinum';
  ELSIF eval_count >= 6 THEN
    new_band := 'gold';
  ELSIF eval_count >= 3 THEN
    new_band := 'silver';
  ELSIF eval_count >= 1 THEN
    new_band := 'bronze';
  ELSE
    new_band := 'unverified';
  END IF;
  
  -- Update the profile's trust_band
  UPDATE profiles
  SET trust_band = new_band,
      updated_at = now()
  WHERE id = NEW.evaluated_id;
  
  RETURN NEW;
END;
$$;

-- Trigger to update trust_band after insert
CREATE TRIGGER trigger_update_trust_band
AFTER INSERT ON peer_reviews
FOR EACH ROW
EXECUTE FUNCTION update_trust_band();

-- Updated_at trigger for profiles
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_profiles_updated_at
BEFORE UPDATE ON profiles
FOR EACH ROW
EXECUTE FUNCTION update_updated_at();

-- ========================================
-- ENABLE ROW LEVEL SECURITY
-- ========================================

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE peer_reviews ENABLE ROW LEVEL SECURITY;

-- ========================================
-- PROFILES TABLE POLICIES
-- ========================================

-- SELECT: Authenticated users can read all profiles
CREATE POLICY "profiles_select_policy"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (true);

-- INSERT: Users can only create their own profile
CREATE POLICY "profiles_insert_policy"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- UPDATE: Users can only update their own profile
-- CRITICAL: This policy prevents trust_band manipulation
-- trust_band is managed by database triggers only
CREATE POLICY "profiles_update_policy"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- ========================================
-- PEER_REVIEWS TABLE POLICIES
-- ========================================

-- SELECT: Authenticated users can read all reviews
CREATE POLICY "peer_reviews_select_policy"
  ON peer_reviews
  FOR SELECT
  TO authenticated
  USING (true);

-- INSERT: Users can only submit reviews as themselves
-- CRITICAL: evaluator_id MUST equal auth.uid()
-- This prevents users from creating reviews on behalf of others
CREATE POLICY "peer_reviews_insert_policy"
  ON peer_reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (evaluator_id = auth.uid());

-- UPDATE: DISABLED - Reviews are immutable
-- No update policy = no updates allowed

-- DELETE: DISABLED - Reviews cannot be removed
-- No delete policy = no deletions allowed