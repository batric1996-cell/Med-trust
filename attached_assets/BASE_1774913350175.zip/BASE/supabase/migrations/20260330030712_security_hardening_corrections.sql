/*
  # Security Hardening Corrections - Zero-Trust Enforcement
  
  ## Changes
  
  1. Restrict peer_reviews SELECT policy - Only allow viewing own reviews
  2. Verify evaluator_id WITH CHECK enforcement
  3. Add UNIQUE constraint check for duplicate submissions
  4. Confirm trust_band is protected from direct updates
*/

-- Drop and recreate peer_reviews SELECT policy with strict access control
DROP POLICY IF EXISTS "peer_reviews_select_policy" ON peer_reviews;

CREATE POLICY "peer_reviews_select_policy"
  ON peer_reviews
  FOR SELECT
  TO authenticated
  USING (
    evaluator_id = auth.uid() OR evaluated_id = auth.uid()
  );

-- Verify INSERT policy enforces evaluator_id (already correct, but explicit confirmation)
DROP POLICY IF EXISTS "peer_reviews_insert_policy" ON peer_reviews;

CREATE POLICY "peer_reviews_insert_policy"
  ON peer_reviews
  FOR INSERT
  TO authenticated
  WITH CHECK (evaluator_id = auth.uid());