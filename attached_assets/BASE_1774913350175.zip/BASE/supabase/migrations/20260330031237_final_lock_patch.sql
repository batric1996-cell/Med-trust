/*
  # Final Lock Patch - Disable Direct peer_reviews Access
  
  ## Changes
  
  1. Remove SELECT policy from peer_reviews table (disable direct access)
  2. Create aggregated VIEW with only safe data (evaluated_id, review count)
  3. Grant SELECT on VIEW to authenticated users
*/

-- Drop SELECT policy on peer_reviews - disable direct access
DROP POLICY IF EXISTS "peer_reviews_select_policy" ON peer_reviews;

-- Create safe aggregated view
CREATE OR REPLACE VIEW peer_reviews_summary AS
SELECT 
  evaluated_id,
  COUNT(*) as total_reviews
FROM peer_reviews
GROUP BY evaluated_id;

-- Grant SELECT on view to authenticated users only
GRANT SELECT ON peer_reviews_summary TO authenticated;

-- Revoke any direct access to peer_reviews table for authenticated users
-- (only INSERT policy remains for writing reviews)