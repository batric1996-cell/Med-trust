import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Profile {
  id: string;
  full_name: string;
  specialty: string;
  trust_band: 'Stable' | 'Strong' | 'Advanced';
  created_at: string;
}

export interface PeerReview {
  id: string;
  evaluator_id: string;
  evaluated_id: string;
  traits: number[];
  created_at: string;
}
