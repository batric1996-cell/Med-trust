import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase, Profile } from '../lib/supabase';
import { DoctorCard } from './DoctorCard';

export function Dashboard() {
  const { signOut, user } = useAuth();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentView, setCurrentView] = useState<'dashboard' | 'profile'>('dashboard');
  const [userProfile, setUserProfile] = useState<Profile | null>(null);

  useEffect(() => {
    loadProfiles();
    if (user) {
      loadUserProfile();
    }
  }, [user]);

  const loadProfiles = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProfiles(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load profiles');
    } finally {
      setLoading(false);
    }
  };

  const loadUserProfile = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      if (error) throw error;
      setUserProfile(data);
    } catch (err) {
      console.error('Error loading user profile:', err);
    }
  };

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <aside className="w-64 bg-white border-r border-slate-200 p-6 hidden md:block">
        <div className="mb-8">
          <h1 className="text-xl font-bold text-slate-900">
            Medical Trust Network
          </h1>
        </div>

        <nav className="space-y-2">
          <button
            onClick={() => setCurrentView('dashboard')}
            className={`w-full text-left px-4 py-2 rounded-lg font-medium ${
              currentView === 'dashboard'
                ? 'bg-slate-100 text-slate-900'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setCurrentView('profile')}
            className={`w-full text-left px-4 py-2 rounded-lg font-medium ${
              currentView === 'profile'
                ? 'bg-slate-100 text-slate-900'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            My Profile
          </button>
          <button
            onClick={handleSignOut}
            className="w-full text-left px-4 py-2 rounded-lg font-medium text-slate-600 hover:bg-slate-50"
          >
            System Exit
          </button>
        </nav>
      </aside>

      <main className="flex-1 p-6 md:p-8">
        <div className="md:hidden mb-6 flex justify-between items-center">
          <h1 className="text-xl font-bold text-slate-900">
            Medical Trust Network
          </h1>
          <button
            onClick={handleSignOut}
            className="text-sm text-slate-600 hover:text-slate-900"
          >
            Exit
          </button>
        </div>

        {currentView === 'dashboard' && (
          <>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">
                Network Directory
              </h2>
              <p className="text-sm text-slate-600">
                Verified medical professionals in the trust network
              </p>
            </div>

            {loading && (
              <p className="text-slate-600">Loading profiles...</p>
            )}

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                <p className="text-sm text-red-600">{error}</p>
              </div>
            )}

            {!loading && !error && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {profiles.map((profile) => (
                  <DoctorCard key={profile.id} profile={profile} />
                ))}
              </div>
            )}

            {!loading && !error && profiles.length === 0 && (
              <p className="text-slate-600">No profiles found</p>
            )}
          </>
        )}

        {currentView === 'profile' && (
          <div className="max-w-2xl">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">
                My Profile
              </h2>
              <p className="text-sm text-slate-600">
                Your professional identity record
              </p>
            </div>

            {userProfile ? (
              <div className="bg-white border border-slate-200 rounded-xl p-8">
                <div className="flex items-start gap-6 mb-6">
                  <img
                    src={userProfile.image_url || 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop'}
                    alt={userProfile.full_name}
                    className="w-24 h-24 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-slate-900 mb-1">
                      {userProfile.full_name}
                    </h3>
                    <p className="text-sm mb-2" style={{ color: '#0055ff' }}>
                      {userProfile.specialty}
                    </p>
                    <span className="text-xs uppercase text-slate-500 border border-slate-300 rounded px-3 py-1">
                      {userProfile.trust_band}
                    </span>
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-slate-700 mb-2">Biography</h4>
                  <p className="text-sm text-slate-600">{userProfile.bio}</p>
                </div>
              </div>
            ) : (
              <p className="text-slate-600">Loading your profile...</p>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
