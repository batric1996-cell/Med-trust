import { Profile } from '../lib/supabase';

type DoctorCardProps = {
  profile: Profile;
};

export function DoctorCard({ profile }: DoctorCardProps) {
  const defaultImage = 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop';

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col items-center text-center">
      <img
        src={profile.image_url || defaultImage}
        alt={profile.full_name}
        className="w-24 h-24 rounded-full object-cover mb-4"
        onError={(e) => {
          e.currentTarget.src = defaultImage;
        }}
      />

      <h3 className="text-lg font-bold text-slate-900 mb-1">
        {profile.full_name}
      </h3>

      <p className="text-sm text-slate-600 mb-3" style={{ color: '#0055ff' }}>
        {profile.specialty}
      </p>

      <p className="text-sm text-slate-600 mb-4 line-clamp-2 min-h-[2.5rem]">
        {profile.bio}
      </p>

      <div className="mb-4">
        <span className="text-xs uppercase text-slate-500 border border-slate-300 rounded px-3 py-1">
          {profile.trust_band}
        </span>
      </div>

      <button className="w-full bg-white border border-slate-300 text-slate-700 py-2 px-4 rounded-lg font-medium hover:bg-slate-50">
        Endorse
      </button>
    </div>
  );
}
