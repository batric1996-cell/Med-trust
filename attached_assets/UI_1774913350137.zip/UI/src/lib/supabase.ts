import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  full_name: string;
  specialty: string;
  bio: string;
  trust_band: string;
  image_url: string;
  is_system_profile: boolean;
  created_at: string;
  updated_at: string;
};
