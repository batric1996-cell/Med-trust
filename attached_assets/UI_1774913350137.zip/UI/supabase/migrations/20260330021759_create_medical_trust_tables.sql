/*
  # Medical Trust Network - Database Schema

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key, references auth.users.id)
      - `full_name` (text, not null)
      - `specialty` (text, not null)
      - `bio` (text)
      - `trust_band` (text, default 'Stable')
      - `image_url` (text)
      - `created_at` (timestamptz, default now())
      - `updated_at` (timestamptz, default now())
    
    - `peer_reviews`
      - `id` (uuid, primary key)
      - `evaluator_id` (uuid, references profiles.id)
      - `evaluated_id` (uuid, references profiles.id)
      - `traits` (integer array)
      - `created_at` (timestamptz, default now())
  
  2. Security
    - Enable RLS on both tables
    - Profiles: authenticated users can read all, update own
    - Peer reviews: authenticated users can read all, insert own reviews
  
  3. Triggers
    - Auto-create profile when user signs up
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  specialty text NOT NULL DEFAULT 'General Practitioner',
  bio text DEFAULT 'Profile pending completion',
  trust_band text DEFAULT 'Stable',
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create peer_reviews table
CREATE TABLE IF NOT EXISTS peer_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  evaluator_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  evaluated_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  traits integer[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  CONSTRAINT different_users CHECK (evaluator_id != evaluated_id)
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE peer_reviews ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Profiles are viewable by authenticated users"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Peer reviews policies
CREATE POLICY "Peer reviews are viewable by authenticated users"
  ON peer_reviews FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own peer reviews"
  ON peer_reviews FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = evaluator_id);

-- Function to handle new user profile creation
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, full_name, specialty, bio, trust_band, image_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, 'New User'),
    'General Practitioner',
    'Profile pending completion',
    'Stable',
    'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to auto-create profile
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();