/*
  # Update Profiles Schema for Sample Data

  1. Changes
    - Drop the FK constraint from profiles to auth.users
    - Add is_system_profile flag to distinguish sample doctors from real users
    - Update RLS policies to handle both types
  
  2. Notes
    - Allows profiles to exist independently for sample/display data
    - Ensures dashboard is never empty
    - Real user profiles still created via trigger
*/

-- Drop the existing FK constraint
ALTER TABLE profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;

-- Add system profile flag
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'is_system_profile'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_system_profile boolean DEFAULT false;
  END IF;
END $$;

-- Update the trigger function to set is_system_profile to false for real users
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, full_name, specialty, bio, trust_band, image_url, is_system_profile)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, 'New User'),
    'General Practitioner',
    'Profile pending completion',
    'Stable',
    'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&h=400&fit=crop',
    false
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;